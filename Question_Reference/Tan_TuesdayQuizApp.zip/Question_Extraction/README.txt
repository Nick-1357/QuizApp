Version 1 of the Question Extraction GUI 

Template folder:
Contains all html files for the web GUI

style.css:
Styling for the html files

App.py:
Database connector and question extraction in this file. All question related logic is in this file.
