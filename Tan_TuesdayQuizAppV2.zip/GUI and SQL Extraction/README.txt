GUI.py

The user interface portion of the code to show the topic selection and the question. Run this file to start the app

ITS.py

SQL connector to the database, all queries to the database are done here. Import this file to get data from database.